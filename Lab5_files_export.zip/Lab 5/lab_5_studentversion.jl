using LinearAlgebra
include("chaos_toolsv2_1.jl")
GLMakie.activate!()

# Here we examine the dynamical behavior of linear maps R^2 -> R^2

mat1 = [4 2;
        5 4]

F1(x, y) = mat1*[x ; y]

λs1 = eigen(mat1).values
γ(t) = [cos(t), sin(t)]

parametric_2d(F1, 2, γ, 0:0.001:(2π))


mat2 = [0.5 1;
        0 0.6]


# your code here


#Give one example of a matrix with two different eigenvalues, both bigger than 1. And rectify with the graph that is a source.  

# your code here


# Try this matrix with repeated eigenvalues less than 1
mat4 = [0.3  1; 
        0  0.3]

# your code here


# Consider this matrix (be careful not to miss anything which a circle might hide...)
mat5 = [4  -1; 
        1  4]

# your code here



#Give one example of a matrix with complex eigenvalues such that their norm is smaller than 1, and show that the graph is a sink.  

# your code here



# Consider the Hénon map for a=0 and b=0.4

Henon(x, y) = [-x^2 + 0.4y,  x]

# Find the Jacobian on paper

# your function definition Here

# Assess its eigenvalues at (0,0)

# your code here

# Make a plot to demonstrate the behavior around (0,0)

# your code here

# Assess the Jacobian's eigenvalues at (-0.6, -0.6)

# your code here

# Make a plot to demonstrate the behavior around (-0.6, -0.6)

# your code here


#Do the same analysis for the Hénon map a=0.43, and b=0.4.

Henon2(x, y) = [0.45 - x^2 + 0.4y,  x]

# Its fixed points are approximately:
# (0.43484692283495342,0.43484692283495342)
# (-1.0348469228,-1.0348469228)