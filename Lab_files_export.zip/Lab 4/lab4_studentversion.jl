include("chaos_toolsv2.jl")
GLMakie.activate!()

# We consider two points nearby each other being acted on by the logistic function with parameter 4.

g(x) = 4x*(1-x)

Y1 = rand()

#INITIAL SEPARATION OF 0.01

Y2 = Y1 - 0.01

#Try the previous with 5 random points within a distance 0.01. How many iterations are required for the points to move apart 0.5?

#INITIAL SEPARATION OF 0.001

# your code here

#Try the previous step with 5 random points within a distance 0.001. How many iteratatinos are required for the points to move apart 0.5?

#The location of the point doesnt matter. Exercise: Do the same process with INITIAL SEPARATION OF 0.0001.

F(x, y) = [-x^2 + 0.4 *y, x]

#We saw in class that F has two fixed points. (0,0) and (-0.6,-0.6). Rectify it!

γ(t) = [0.2*cos(t), 0.2*sin(t)]

parametric_2d(F, 20, γ, 0:0.02:2*π)

# Conclude that the fixed point (0,0) is _____________ 


#Do the same for the point (-0.6,-0.6) and conclude its stability. They should conclude __________ 


# Try an initial curve which passes near both points! 