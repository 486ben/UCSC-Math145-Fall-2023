include("chaos_toolsv3.jl")
GLMakie.activate!()


g(x) = 2.5x*(1 - x)

# Define a function which takes the parameter a of ax(1-x) and returns the non-zero fixed point.


# Compute the absolute value of the derivative of g at the fixed point.


# Conclude that ___ is ___________ fixed point.
# Compute the Lyapunov number and exponent of g at [fixed point] without loops or lists.



# Check that most bounded orbits tend to the fixed point. Therefore, most bounded orbits are asymptotically periodic.  

itg(g, rand(), 20)
cobwebPlotStartBar(g, 300, 0:0.001:1)

# Therefore the Lyapunov number of most bounded orbits is _______

# Let's consider the logistic map in general. Try some Lyapunov exponent approximations.
logistic(a) = x -> a*x*(1-x)
logisticPrime(a) = x -> a*(1-2x)

# Try a = 3.86 with a random starting point.
lyapunovPoint(x) = log(abs(logisticPrime(3.86)(x)))


# Notice that the convergence rate can be very slow.
x = rand()
mean(lyapunovPoint.(itg(logistic(3.86), x, 1000)))
mean(lyapunovPoint.(itg(logistic(3.86), x, 10000)))
mean(lyapunovPoint.(itg(logistic(3.86), x, 100000)))


# Let's plot the Lyapunov exponent against the possible values of a!

lyapunovGraph(0:0.001:4, logistic, 0.4, 5000)
lyapunovBifurcation((a, t) -> logistic(a)(t), 1000, 0:0.001:4, 0.4, 0.1:0.2:0.9)

# Discuss how the Lyapunov exponent corresponds to the bifurcation graph.

# Let's re-evaluate the Lyapunov graph just before chaos breaks at a = 3.56995
lyapunovGraph(3.54:0.00001:3.56995, logistic, 0.4, 5000)

lyapunovGraph(3.55:0.00001:3.56995, logistic, 0.4, 5000)


lyapunovGraph(3.565:0.00001:3.56995, logistic, 0.4, 5000)

lyapunovGraph(3.569:0.000001:3.56995, logistic, 0.4, 50000)

# WARNING: NUMERICAL STABILITY ISSUES
lyapunovGraph(3.5699:0.0000001:3.56995, logistic, 0.4, 300000)

# Let's also look at both the Lyapunov and bifurcation diagrams in the chaotic region
lyapunovBifurcation((a, t) -> logistic(a)(t), 1000, 3.56995:0.0001:4, 0.4, 0.1:0.2:0.9)



# Let's try another familiar map.

h(x) = 2x % 1

lines(0:0.001:1, h)

# Remember that due to numerical stability issues, all floating point starting points are practically sensitive.
# Show that graphically.

# Let's check Lyapunov numbers!

# Let's try a rational input!


# What about Lyapunov numbers at rational points?
# Conclude that the Lyapunov number of a fixed point is _____


# Let's do it again with a new function!

η(x) = if (x < 0.5) 2x else 2-2x end
lines(0:0.001:1,η)