include("chaos_toolsv2_2.jl")
GLMakie.activate!()
using LinearAlgebra

# This is the Henon family of maps for varying a and b = 0.4
HenonFamily(a, x, y) = [a - x^2 + 0.4y, x]

# Using the quadratic formula, we know that the two fixed points are given by:

x1(a) = (-0.6 + sqrt(0.36 + 4a))/2

x2(a) = (-0.6 - sqrt(0.36 + 4a))/2

# We compute the Jacobian of the Henon map with b=0.4. Note that since a changes it by a constant, the Jacobian does not depend on a.  

J(x, y) = [-2x 0.4; 1 0]

# Computing the eigenvalues of the Jacobian at the first fixed point (x1, x1)

# Here, λ12 is the *1st* fixed point's *2nd* eigenvalue, hence the notation.
λ11(a) = (eigen(J(x1(a), x1(a))).values)[1]
λ12(a) = (eigen(J(x1(a), x1(a))).values)[2]


#From the following  graph we can see that both eigenvalues  are smaller than one for -0.09<a<0.27. From this conclude that always for this range of a, the Hénon map for b=0.4, has a sink. 

fig = Figure(); ax = Axis(fig[1,1])
aRange = -0.09:0.001:0.27
lines!(ax, aRange, λ11.(aRange))
lines!(ax, aRange, λ12.(aRange))
fig


#Exercise: using the same strategy, prove that for -0.09<a<0.27, the Hénon map for b=0.4, has a saddle.

# We compute the eigenvalues λ21, λ22 of the Jacobian at the second fixed point (x2, x2)

λ21(a) = (eigen(J(x2(a), x2(a))).values)[1]
λ22(a) = (eigen(J(x2(a), x2(a))).values)[2]


#From the following  graph we can see that one eigenvalue is smaller than 1 and another eigenvalue is bigger than 1 for -0.09<a<0.27. From this conclude that always for this range of a, the Hénon map for b=0.4, has a saddle. 

fig = Figure(); ax = Axis(fig[1,1])
aRange = -0.09:0.001:0.27
lines!(ax, aRange, λ21.(aRange))
lines!(ax, aRange, λ22.(aRange))
fig



# bifurcation21 is the bifurcation for a *2*D map's *1st* coordinate. Mouse over the function for more info.
bifurcation21(HenonFamily, 1500, 0:0.0001:1.1, 10, 0, 0.5)


# Look at the window of *non* stability!

# Notice how this one is different, less clean even, than the ones we generated for 1D maps


# Let's find the attractors of the Henon map for b= 0.4, a = 0.9, 0.96, 0.975, 1, 1.045, 1.2, 1.25.
# The first a value is provided for you.

# It's ok to just pick a random (x,y) in the unit square and stick with it.

x = rand()
y = rand()

# First, a = 0.9

H(x,y) = HenonFamily(0.9, x, y)

h1000 = twoDFPower(H, 1000, x, y)

j(n) = twoDFPower(H,n,h1000[1], h1000[2])


xValues = [j(i)[1] for i = 1:5000]
yValues = [j(i)[2] for i = 1:5000]

fig = Figure(); ax = Axis(fig[1,1])
scatter!(ax, xValues, yValues, markersize=2)
fig


# a = 0.965, in the "satellite chaos" region



# a = 0.975. What happens here?



# a = 1



# a = 1.045



# a = 1.2



# a = 1.25


